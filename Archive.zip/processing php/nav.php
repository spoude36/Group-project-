		<div class="nav-bar">
            <a href="index.php">HOME |</a>
            <a href="menu.php">MENU |</a>
            <a href="reservation.php">RESERVATION |</a>
            <a href="about-us.php">ABOUT US |</a>
            <a href="contact-us.php">CONTACT US |</a>
            <a href="admin.php">ADMIN PANEL |</a>
        </div>