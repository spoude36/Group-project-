<!DOCTYPE html>
<html lang="en">
<head>
    <title>Local Restaurant</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
    <div class="maindiv">
        <div class="header">
            <div class="header-logo">
                <a href="index.html"><img height="100%" src="images/logo.png" /></a>
            </div>
            
        </div>