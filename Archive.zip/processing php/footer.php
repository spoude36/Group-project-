        <div class="footer">
            
            <div class="footer-inside">
                <p>We are Open</p>
                <p>11:00 AM to 10:00 PM</p>
            </div>
            <div class="footer-inside">
                <p>Footer Navigation</p>
                <p><a href="index.php">HOME |</a></p>
                <p><a href="menu.php">MENU |</a></p>
                <p><a href="reservation.php">RESERVATION |</a></p>
                <p><a href="about-us.php">ABOUT US |</a></p>
                <p><a href="contact-us.php">CONTACT US |</a></p>
                <p><a href="admin.php">ADMIN PANEL |</a></p>
            </div>
            <div class="footer-inside">
                
                <p><b>Developed By: </b> </p> 
                    <p>Pradhuman Yadav</p>
                    <p> Rupesh Chaudhary </p> 
                    <p>Aaush Thapa and Jatten Sharma</p>
                <p><b>@ 2023 by Local Restaurant</b></p>
            </div>


            
            <div class="clr"></div>

            <p> </p>
        </div>
    </div>
</body>
</html>