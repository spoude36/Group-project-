		<div class="nav-bar">
            <a href="admin-home.php">ADMIN HOME |</a>
            <a href="admin-food-category.php">FOOD CATEGORY |</a>
            <a href="admin-food-menu.php">MANAGE FOOD MENU |</a>
            <a href="admin-all-reservation.php">All RESERVATION |</a>
            <a href="admin-today-reservation.php">TODAY RESERVATION |</a>
            <a href="logout.php">LOGOUT |</a>
        </div>