<?php include('header.php');?>
<?php include('nav.php');?>
       
        <div class="content">
            <div class="content">
                <h1>Welcome to Local Restaurant</h1>

                <h2>ADMIN LOGIN FAILED</h2>
                <div class="imagediv">
                    <img src="images/failed.jpeg" alt="no image found" />
                </div>
                 <p>Your username and password does not match. Please enter valid username and password to continue. </p>                
                
            </div>


        </div>

<?php include('footer.php');?>
